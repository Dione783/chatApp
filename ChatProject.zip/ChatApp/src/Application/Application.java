package Application;

import java.util.Scanner;

public class Application {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Sala 41:");
        System.out.println("Enviar Mensagem:");
        sc.next();
    }
}